from .player import start_game

__all__ = ["start_game"]